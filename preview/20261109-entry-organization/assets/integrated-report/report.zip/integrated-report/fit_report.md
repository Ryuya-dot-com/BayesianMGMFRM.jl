# BayesianMGMFRM fit report

Generated from `bayesianmgmfrm.fit_report_public.v1`.

- Report content hash: `a382cb1f126a2674c51ca9dd25616b68fc6de1f3ec51356166b804a972e7edf2`
- Markdown preview rows per table: 3

## Report Metadata

| field | value |
| --- | --- |
| schema | bayesianmgmfrm.fit_report_public.v1 |
| object | fit_report_public |
| created_at | 2026-10-12T17:22:03.694 |
| family | mgmfrm |
| thresholds | partial_credit |
| dimensions | 2 |
| dimension_labels | ["dim=1","dim=2"] |
| status | experimental |
| report_status | complete |
| model_label | Normalized-prior MGMFRM (estimated loadings and consistency) |
| backend_label | Julia (AdvancedHMC) |
| scale_convention | Prior-anchored model coordinates; response multiplier 1.7; identity latent correlation |
| target_identity | d06359db5587c45080aabe32b233faeaebf0c3bb257318d4f18a22c22aed6004 |
| source_sample_schema | bayesianmgmfrm.normalized_fixed_q_samples.v2 |
| source_sample_content_hash | 7004183f94a5b7b0d3f01beb6dd30bc79783517d9a4b2a19b062cf2a79a9af7f |

## Warnings

| section | code | severity | n_affected_rows | message | action |
| --- | --- | --- | --- | --- | --- |
| category_report | mcse_unavailable | warning |  | Some Monte Carlo error estimates are unavailable; constant sampled indicators do not establish certainty. | inspect_quantity_mcse |
| category_report | category_review | warning |  | Category-use or step-order flags require substantive review; no category collapse is implied. | review_category_support_and_ordering |

## Section Summary

| section | status | n_rows |
| --- | --- | --- |
| diagnostics | computed | 287 |
| warmup | computed | 4 |
| rating_design | computed | 11 |
| fixed_coordinates | computed | 5 |
| category_functioning | unsupported | 0 |
| rater_homogeneity | unsupported | 0 |
| category_report | computed | 205 |
| posterior_reliability | computed | 102 |
| rater_agreement | computed | 32 |
| q_matrix | computed | 10 |
| mcmc_budget_guidance | unsupported | 0 |
| prior_policy | computed | 6 |
| pooling_policy | computed | 0 |
| prior_predictive | not_requested | 0 |
| posterior | computed | 128 |
| direct_posterior | computed | 280 |
| posterior_predictive | not_requested | 0 |
| calibration | unsupported | 0 |
| waic | not_requested | 0 |
| loo | not_requested | 0 |
| dff | unsupported | 0 |
| artifact | not_requested | 0 |

## Table Previews

### diagnostics

Whole-fit diagnostics use all retained draws and the saved thresholds, even when prediction selects a subset. Inspect raw and direct coordinates, divergences, tree depth and energy coverage before inference. Report completeness does not establish MCMC quality.


### diagnostics / sampler_rows

- Rows: 4
- Preview rows: 3

| parameter_space | backend | sampler | chain | n_divergences | n_max_treedepth | n_nonfinite_logdensity | flag | acceptance_rate | diagnostic_method | diagnostic_row | diagnostic_status | e_bfmi | first_iteration | last_iteration | max_tree_depth | maximum_logdensity | mean_logdensity | mean_n_steps | mean_step_size | mean_tree_depth | minimum_logdensity | n_draws | n_finite_logdensity | step_size | warmup |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| raw_unconstrained | advancedhmc | nuts | 1 | 0 | 0 | 0 | ok | 0.9243353013934025 | sampler_chain_summary | sampler_chain | recorded | 0.6954721464778102 | 1 | 1000 | 6 | -1240.965587552865 | -1270.3053941647584 | 21.784 | 0.2064098510249044 | 4.133 | -1306.8512038942965 | 1000 | 1000 | 0.03 | 1000 |
| raw_unconstrained | advancedhmc | nuts | 2 | 0 | 0 | 0 | ok | 0.9307659315473555 | sampler_chain_summary | sampler_chain | recorded | 0.7832312442425023 | 1 | 1000 | 7 | -1240.0390139942988 | -1270.5090421134125 | 27.64 | 0.20403891108031863 | 4.331 | -1309.7533461126652 | 1000 | 1000 | 0.03 | 1000 |
| raw_unconstrained | advancedhmc | nuts | 3 | 0 | 0 | 0 | ok | 0.918294590860521 | sampler_chain_summary | sampler_chain | recorded | 0.7599547430981528 | 1 | 1000 | 6 | -1238.5743254972272 | -1271.15417605088 | 17.72 | 0.21618571720816246 | 4.043 | -1312.0486053986351 | 1000 | 1000 | 0.03 | 1000 |

*1 additional row(s) omitted.*

### diagnostics / parameter_rows

- Rows: 128
- Preview rows: 3

| parameter | parameter_space | rhat | rank_normalized_rhat | ess | bulk_ess | tail_ess | flag | autocovariance_maxlag | bulk_rank_normalized_rhat | classical_compatibility_flag | diagnostic_chains | diagnostic_contract | diagnostic_draws_per_chain | diagnostic_method | diagnostic_row | diagnostic_status | draws_per_chain | folded_rank_normalized_rhat | n_chains | quality_gate_applicable | rank_normalized_flag | split_chains | split_chains_requested | tail_probability | total_draws |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| person[P1,dim=1] | raw_unconstrained | 0.9995429651561752 | 1.0015533392207971 | 4000 | 4054.703361506417 | 2640.3863329276605 | ok | 496 | 0.9996003770813496 | ok | 8 | rank_normalized_rhat_bulk_tail_ess_v1 | 500 | rank_normalized_split_rhat_bulk_tail_ess | parameter | rank_normalized_available | 1000 | 1.0015533392207971 | 4 | true | ok | true | true | 0.1 | 4000 |
| person[P1,dim=2] | raw_unconstrained | 0.9998987566926916 | 1.0011939146309667 | 3714.578421800525 | 3674.426285432474 | 2844.439580118028 | ok | 496 | 0.9999214858909993 | ok | 8 | rank_normalized_rhat_bulk_tail_ess_v1 | 500 | rank_normalized_split_rhat_bulk_tail_ess | parameter | rank_normalized_available | 1000 | 1.0011939146309667 | 4 | true | ok | true | true | 0.1 | 4000 |
| person[P10,dim=1] | raw_unconstrained | 0.9997645674539803 | 1.0006636610750215 | 4000 | 4603.178377651795 | 3037.5486262597683 | ok | 496 | 0.9997513914404836 | ok | 8 | rank_normalized_rhat_bulk_tail_ess_v1 | 500 | rank_normalized_split_rhat_bulk_tail_ess | parameter | rank_normalized_available | 1000 | 1.0006636610750215 | 4 | true | ok | true | true | 0.1 | 4000 |

*125 additional row(s) omitted.*

### diagnostics / block_rows

- Rows: 6
- Preview rows: 3

| parameter_space | block | flag | autocovariance_maxlag | classical_compatibility_flag | diagnostic_contract | diagnostic_method | diagnostic_row | diagnostic_status | draws_per_chain | ess_threshold | first_parameter | last_parameter | max_rank_normalized_rhat | max_rhat | min_bulk_ess | min_ess | min_tail_ess | n_bad_rank_normalized_rhat | n_bad_rhat | n_chains | n_degenerate_parameters | n_insufficient_chains | n_insufficient_draws | n_low_bulk_ess | n_low_ess | n_low_tail_ess | n_nonfinite_parameters | n_parameters | n_quality_gate_parameters | n_structurally_fixed_parameters | parameter_names | quality_gate_applicable | rank_normalized_flag | rhat_threshold | split_chains | split_chains_requested | total_draws |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| raw_unconstrained | item | ok | 496 | ok | rank_normalized_rhat_bulk_tail_ess_v1 | rank_normalized_split_rhat_bulk_tail_ess | parameter_block | rank_normalized_available | 1000 | 400 | 105 | 109 | 1.0011706322928293 | 1.0009188548690384 | 2567.852012256181 | 2526.3919158173585 | 2512.21833714605 | 0 | 0 | 4 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 5 | 5 | 0 | ["item[I1]","item[I2]","item[I3]","item[I4]","item[I5]"] | true | ok | 1.01 | true | true | 4000 |
| raw_unconstrained | item_steps | ok | 496 | ok | rank_normalized_rhat_bulk_tail_ess_v1 | rank_normalized_split_rhat_bulk_tail_ess | parameter_block | rank_normalized_available | 1000 | 400 | 119 | 128 | 1.0016400334382043 | 1.0015036594738644 | 1977.3244991331007 | 1816.7983236814227 | 2253.591643476463 | 0 | 0 | 4 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 10 | 10 | 0 | ["item_step[item=I1,m=2]","item_step[item=I1,m=3]","item_step[item=I2,m=2]","item_step[item=I2,m=3]","item_step[item=I3,... | true | ok | 1.01 | true | true | 4000 |
| raw_unconstrained | log_item_dimension_discrimination | ok | 496 | ok | rank_normalized_rhat_bulk_tail_ess_v1 | rank_normalized_split_rhat_bulk_tail_ess | parameter_block | rank_normalized_available | 1000 | 400 | 110 | 114 | 1.0055148100836495 | 1.0053960072568286 | 794.220254732521 | 806.0128785195594 | 1694.9075007852798 | 0 | 0 | 4 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 5 | 5 | 0 | ["raw_log_item_dimension_discrimination[item=I1,dim=1]","raw_log_item_dimension_discrimination[item=I2,dim=1]","raw_log_... | true | ok | 1.01 | true | true | 4000 |

*3 additional row(s) omitted.*

### diagnostics / direct_block_rows

- Rows: 6
- Preview rows: 3

| parameter_space | block | flag | autocovariance_maxlag | classical_compatibility_flag | diagnostic_contract | diagnostic_method | diagnostic_row | diagnostic_status | draws_per_chain | ess_threshold | first_parameter | last_parameter | max_rank_normalized_rhat | max_rhat | min_bulk_ess | min_ess | min_tail_ess | n_bad_rank_normalized_rhat | n_bad_rhat | n_chains | n_degenerate_parameters | n_insufficient_chains | n_insufficient_draws | n_low_bulk_ess | n_low_ess | n_low_tail_ess | n_nonfinite_parameters | n_parameters | n_quality_gate_parameters | n_structurally_fixed_parameters | parameter_names | quality_gate_applicable | rank_normalized_flag | rhat_threshold | split_chains | split_chains_requested | total_draws |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| direct_constrained | item | ok | 496 | ok | rank_normalized_rhat_bulk_tail_ess_v1 | rank_normalized_split_rhat_bulk_tail_ess | parameter_block | rank_normalized_available | 1000 | 400 | 106 | 110 | 1.0011706322928293 | 1.0009188548690384 | 2567.852012256181 | 2526.3919158173585 | 2512.21833714605 | 0 | 0 | 4 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 5 | 5 | 0 | ["item[I1]","item[I2]","item[I3]","item[I4]","item[I5]"] | true | ok | 1.01 | true | true | 4000 |
| direct_constrained | item_dimension_discrimination | ok | 496 | ok | rank_normalized_rhat_bulk_tail_ess_v1 | rank_normalized_split_rhat_bulk_tail_ess | parameter_block | rank_normalized_available | 1000 | 400 | 111 | 115 | 1.0055148100836495 | 1.0055741213187166 | 794.220254732521 | 796.6556121588704 | 1694.9075007852798 | 0 | 0 | 4 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 5 | 5 | 0 | ["item_dimension_discrimination[item=I1,dim=1]","item_dimension_discrimination[item=I2,dim=1]","item_dimension_discrimin... | true | ok | 1.01 | true | true | 4000 |
| direct_constrained | item_steps | ok | 496 | ok | rank_normalized_rhat_bulk_tail_ess_v1 | rank_normalized_split_rhat_bulk_tail_ess | parameter_block | rank_normalized_available | 1000 | 400 | 121 | 130 | 1.0016400334382043 | 1.0015036594738644 | 1977.3244991331007 | 1816.7983236814227 | 2253.591643476463 | 0 | 0 | 4 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 10 | 10 | 0 | ["item_step[item=I1,m=2]","item_step[item=I1,m=3]","item_step[item=I2,m=2]","item_step[item=I2,m=3]","item_step[item=I3,... | true | ok | 1.01 | true | true | 4000 |

*3 additional row(s) omitted.*

### diagnostics / direct_constraint_rows

- Rows: 9
- Preview rows: 3

| block | constraint | constraint_index | max_abs_target_error | maximum_value | minimum_value | n_draws | n_failed | passed | target | tolerance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| rater | rater_sum_to_zero | 1 | 0 | 0 | 0 | 4000 | 0 | true | 0 | 1.0e-8 |
| item_dimension_discrimination | item_dimension_discrimination_positive | 2 | 0.8380737720009224 | 0.8380737720009224 | 0.27650203986046074 | 4000 | 0 | true | 0 | 0 |
| rater_consistency | rater_consistency_positive | 3 | 0.8890823816087395 | 0.8890823816087395 | 0.4277935667725711 | 4000 | 0 | true | 0 | 0 |

*6 additional row(s) omitted.*

### diagnostics / direct_parameter_rows

- Rows: 130
- Preview rows: 3

| parameter | parameter_space | rhat | rank_normalized_rhat | ess | bulk_ess | tail_ess | flag | autocovariance_maxlag | bulk_rank_normalized_rhat | classical_compatibility_flag | diagnostic_chains | diagnostic_contract | diagnostic_draws_per_chain | diagnostic_method | diagnostic_row | diagnostic_status | draws_per_chain | folded_rank_normalized_rhat | n_chains | quality_gate_applicable | rank_normalized_flag | split_chains | split_chains_requested | tail_probability | total_draws |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| person[P1,dim=1] | direct_constrained | 0.9995429651561752 | 1.0015533392207971 | 4000 | 4054.703361506417 | 2640.3863329276605 | ok | 496 | 0.9996003770813496 | ok | 8 | rank_normalized_rhat_bulk_tail_ess_v1 | 500 | rank_normalized_split_rhat_bulk_tail_ess | parameter | rank_normalized_available | 1000 | 1.0015533392207971 | 4 | true | ok | true | true | 0.1 | 4000 |
| person[P1,dim=2] | direct_constrained | 0.9998987566926916 | 1.0011939146309667 | 3714.578421800525 | 3674.426285432474 | 2844.439580118028 | ok | 496 | 0.9999214858909993 | ok | 8 | rank_normalized_rhat_bulk_tail_ess_v1 | 500 | rank_normalized_split_rhat_bulk_tail_ess | parameter | rank_normalized_available | 1000 | 1.0011939146309667 | 4 | true | ok | true | true | 0.1 | 4000 |
| person[P10,dim=1] | direct_constrained | 0.9997645674539803 | 1.0006636610750215 | 4000 | 4603.178377651795 | 3037.5486262597683 | ok | 496 | 0.9997513914404836 | ok | 8 | rank_normalized_rhat_bulk_tail_ess_v1 | 500 | rank_normalized_split_rhat_bulk_tail_ess | parameter | rank_normalized_available | 1000 | 1.0006636610750215 | 4 | true | ok | true | true | 0.1 | 4000 |

*127 additional row(s) omitted.*

### diagnostics / warmup_rows

- Rows: 4
- Preview rows: 3

| phase | backend | chain | expected_iterations | observed_iterations | coverage | n_divergences | n_max_treedepth | n_nonfinite_logdensity |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| warmup | advancedhmc | 1 | 1000 | 1000 | recorded | 7 | 0 | 0 |
| warmup | advancedhmc | 2 | 1000 | 1000 | recorded | 6 | 0 | 0 |
| warmup | advancedhmc | 3 | 1000 | 1000 | recorded | 6 | 0 | 0 |

*1 additional row(s) omitted.*

### warmup

Warmup describes NUTS adaptation or random-walk burn-in. Random walk reports rejected nonfinite proposals; its NUTS event fields do not apply. These counts remain separate from convergence diagnostics and retained-draw warnings. Coverage: recorded = observed; not_run = known zero warmup; not_recorded = history unavailable. Unavailable or inapplicable counts are null in JSON and blank in Markdown, never zero. No warmup pass/fail rule is applied.


### warmup / rows

- Rows: 4
- Preview rows: 3

| phase | backend | chain | expected_iterations | observed_iterations | coverage | n_divergences | n_max_treedepth | n_nonfinite_logdensity |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| warmup | advancedhmc | 1 | 1000 | 1000 | recorded | 7 | 0 | 0 |
| warmup | advancedhmc | 2 | 1000 | 1000 | recorded | 6 | 0 | 0 |
| warmup | advancedhmc | 3 | 1000 | 1000 | recorded | 6 | 0 | 0 |

*1 additional row(s) omitted.*

### rating_design / rows

- Rows: 11
- Preview rows: 3

| status | audit | max_count | min_count | n_components | n_expected | n_missing | n_observed | n_repeated | n_sparse | note | severity | unit |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| connected | rating_graph_components | 60 | 60 | 1 |  |  |  |  |  | person_rater_item_graph_connected | info |  |
| connected | rater_linking | 250 | 250 | 1 |  | 0 | 10 |  | 0 | rater_overlap_links_graph_at_minimum_threshold | info | person_item |
| not_declared | anchor_coverage |  |  |  |  | 0 | 0 |  |  | anchors_not_declared | info |  |

*8 additional row(s) omitted.*

### fixed_coordinates

Baseline steps and any single-rater constraints are fixed. Active loadings are estimated; inactive Q entries are zero.


### fixed_coordinates / rows

- Rows: 5
- Preview rows: 3

| parameter | block | fixed | value |
| --- | --- | --- | --- |
| item_step[item=I1,m=1] | item_steps | true | 0 |
| item_step[item=I2,m=1] | item_steps | true | 0 |
| item_step[item=I3,m=1] | item_steps | true | 0 |

*2 additional row(s) omitted.*

### category_functioning

Category-functioning analysis is not connected for this MGMFRM result.


### rater_homogeneity

Rater-homogeneity analysis is not connected for this MGMFRM result.


### category_report

Conditional expected category use on the observed rating allocation; posterior SD and pointwise equal-tailed intervals omit new-rating realization noise. Native step ownership and fixed-ability profile conditions are retained. Steps and adjacent equal-probability ability crossings differ. No HDI, simultaneous band, automatic category collapse or new-level guarantee. Every original retained draw contributes, independently of report prediction draw selection. Detailed quantile MCSE, source identity and controls remain in result.


### category_report / usage_rows

- Rows: 44
- Preview rows: 3

| facet | level | category | expected_fixed | expected_interval_method | expected_interval_probability | expected_lower | expected_mcse_status | expected_mean | expected_mean_mcse | expected_sd | expected_summary_status | expected_upper | level_index | n_observations | observed_count | observed_flag | observed_minus_expected | observed_proportion | threshold_levels | threshold_owner |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| overall |  | 1 | false | equal_tailed | 0.99 | 0.21059985375810708 | available | 0.23102122961945062 | 0.000125483949372895 | 0.007911267492272353 | descriptive | 0.2512770810212847 |  | 1250 | 288 | ok | -0.0006212296194506306 | 0.2304 | ["I1","I2","I3","I4","I5"] | item |
| overall |  | 2 | false | equal_tailed | 0.99 | 0.2343468400680661 | available | 0.2617488733371566 | 0.00017758494866224612 | 0.01090692175184715 | descriptive | 0.28999916100352735 |  | 1250 | 327 | ok | -0.00014887333715657425 | 0.2616 | ["I1","I2","I3","I4","I5"] | item |
| overall |  | 3 | false | equal_tailed | 0.99 | 0.24796327413398528 | available | 0.27572350376130517 | 0.00016944185904641814 | 0.011168709059744025 | descriptive | 0.3050675857055345 |  | 1250 | 347 | ok | 0.001876496238694847 | 0.2776 | ["I1","I2","I3","I4","I5"] | item |

*41 additional row(s) omitted.*

### category_report / threshold_rows

- Rows: 15
- Preview rows: 3

| parameter | mean | sd | lower | upper | fixed | from_category | gap_fixed | gap_interval_method | gap_interval_probability | gap_lower | gap_mcse_status | gap_mean | gap_mean_mcse | gap_sd | gap_summary_status | gap_upper | interval_method | interval_probability | mcse_status | mean_mcse | order_mcse_status | order_mean_mcse | order_probability | ordering_flag | owner | owner_index | owner_level | step | summary_status | to_category |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| item_step[item=I1,m=2] | -1.1758404951601502 | 0.1918421837527216 | -1.7246223578168394 | -0.7406044087820954 | false | 1 |  | not_applicable |  |  | not_applicable |  |  |  | not_applicable |  | equal_tailed | 0.99 | available | 0.004413856098869122 | not_applicable |  |  | not_applicable | item | 1 | I1 | 1 | descriptive | 2 |
| item_step[item=I1,m=3] | 0.1664628905664192 | 0.12011816397912864 | -0.13554354376839772 | 0.48439370467732135 | false | 2 | false | equal_tailed | 0.99 | 0.665052775882621 | available | 1.3423033857265692 | 0.006450774903848246 | 0.29028260690910984 | descriptive | 2.142930199880243 | equal_tailed | 0.99 | available | 0.002313620279100424 | degenerate_draws |  | 1 | likely_ordered | item | 1 | I1 | 2 | descriptive | 3 |
| item_step[item=I1,m=4] | 1.0093776045937306 | 0.13490589940959183 | 0.6804538439679201 | 1.4030389623794282 | false | 3 | false | equal_tailed | 0.99 | 0.42572373655908874 | available | 0.8429147140273112 | 0.002762211639666285 | 0.1686787673640119 | descriptive | 1.3092686707352608 | equal_tailed | 0.99 | available | 0.0027950866858951462 | degenerate_draws |  | 1 | likely_ordered | item | 1 | I1 | 3 | descriptive | 4 |

*12 additional row(s) omitted.*

### category_report / warning_rows

- Rows: 2
- Preview rows: 2

| action | code | cohort_id | message | severity |
| --- | --- | --- | --- | --- |
| inspect_quantity_mcse | mcse_unavailable |  | Some Monte Carlo error estimates are unavailable; constant sampled indicators do not establish certainty. | warning |
| review_category_support_and_ordering | category_review |  | Category-use or step-order flags require substantive review; no category collapse is implied. | warning |

### category_report / crossing_rows

- Rows: 27
- Preview rows: 3

| mean | sd | lower | upper | status | fixed | from_category | interval_method | interval_probability | mcse_status | mean_mcse | owner | owner_level | profile_id | step | summary_status | to_category |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| -5.827441550803535 | 1.0709150502571865 | -9.383503973332829 | -3.6088261371780526 | descriptive | false | 1 | equal_tailed | 0.99 | available | 0.027928683677870977 | item | I1 | item-1-rater-1 | 1 | descriptive | 2 |
| -3.2730501925077524 | 0.628896427277794 | -5.337657771436019 | -2.007449450811413 | descriptive | false | 2 | equal_tailed | 0.99 | available | 0.016226215572981366 | item | I1 | item-1-rater-1 | 2 | descriptive | 3 |
| -1.6761325682221968 | 0.46570465341290557 | -3.1412942588111767 | -0.7095085906877925 | descriptive | false | 3 | equal_tailed | 0.99 | available | 0.010490053729350439 | item | I1 | item-1-rater-1 | 3 | descriptive | 4 |

*24 additional row(s) omitted.*

### category_report / curve_rows

- Rows: 108
- Preview rows: 3

| category | mean | sd | lower | upper | ability | active_dimension | fixed | interval_method | interval_probability | mcse_status | mean_mcse | profile_id | summary_status |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 0.018130654898810022 | 0.013180087560337091 | 0.002226151554875988 | 0.0798445647031946 | -2 | true | false | equal_tailed | 0.99 | available | 0.00028634483067112656 | item-1-rater-1 | descriptive |
| 2 | 0.20148834408001243 | 0.06526839954447493 | 0.0785301362986162 | 0.4071623765000605 | -2 | true | false | equal_tailed | 0.99 | available | 0.0016117943881252394 | item-1-rater-1 | descriptive |
| 3 | 0.43790175551272387 | 0.04089027330314155 | 0.33505031213417813 | 0.5586959144295636 | -2 | true | false | equal_tailed | 0.99 | available | 0.0007840171501630664 | item-1-rater-1 | descriptive |

*105 additional row(s) omitted.*

### category_report / profile_rows

- Rows: 9
- Preview rows: 3

| item | rater | dimension | dimension_label | id | item_index | rater_index |
| --- | --- | --- | --- | --- | --- | --- |
| I1 | R1 | 1 | dim=1 | item-1-rater-1 | 1 | 1 |
| I2 | R1 | 1 | dim=1 | item-2-rater-1 | 2 | 1 |
| I3 | R1 | 2 | dim=2 | item-3-rater-1 | 3 | 1 |

*6 additional row(s) omitted.*

### posterior_reliability

Finite-cohort posterior reliability for each explicitly selected location block and dimension. Absolute and jointly centered targets differ. Weights and components are retained; MCSE measures numerical precision. No reliability CrI, population/design coefficient, conventional separation or Strata is computed. Fixed anchors and mixed dimensions are rejected. Every original retained draw contributes. A failed cohort remains listed and does not discard successful cohorts.


### posterior_reliability / rows

- Rows: 2
- Preview rows: 2

| parameter_space | block | dimension | status | between_variance | cohort_id | interval | mcse_status | mean_mcse | n_levels | n_retained_draws | reliability | result_status | sampling_warning | separation | strata | target | total_variance | within_variance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| model_coordinate | person | 1 | computed | 0.7060545462601134 | All 50 persons, dimension 1 | not_computed | available | 0.001052544368594018 | 50 | 4000 | 0.794889121006663 | descriptive | false | not_computed | not_computed | centered | 0.888242809721628 | 0.18218826346151445 |
| model_coordinate | person | 2 | computed | 0.8827183343976004 | All 50 persons, dimension 2 | not_computed | available | 0.0005101972598227973 | 50 | 4000 | 0.920045920208886 | descriptive | false | not_computed | not_computed | centered | 0.959428562214796 | 0.07671022781719555 |

### posterior_reliability / coordinate_rows

- Rows: 100
- Preview rows: 3

| parameter | parameter_space | block | dimension | dimension_label | cohort_id | derived | empirical_zero_variance | fixed | posterior_mean | posterior_variance | weight |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| person[P1,dim=1] | model_coordinate | person | 1 | dim=1 | All 50 persons, dimension 1 | false | false | false | -0.8194344374883844 | 0.16282135533296047 | 0.02 |
| person[P10,dim=1] | model_coordinate | person | 1 | dim=1 | All 50 persons, dimension 1 | false | false | false | 0.07165786159498908 | 0.1687234229964048 | 0.02 |
| person[P11,dim=1] | model_coordinate | person | 1 | dim=1 | All 50 persons, dimension 1 | false | false | false | -0.598277669556725 | 0.16597748752556554 | 0.02 |

*97 additional row(s) omitted.*

### rater_agreement

Exact/adjacent score agreement on explicitly matched responses and items, weighted by unordered rating-pair opportunities. Observed rates, optional person-cluster observed SE, conditional expected-rate posterior intervals and Monte Carlo error answer different questions. There is no predictive interval, kappa or diagnosis of halo/dependence. Zero-overlap pairs remain unavailable. Every original retained draw contributes. Matching identities, denominators, assumptions and detailed MCSE remain in result.


### rater_agreement / rows

- Rows: 32
- Preview rows: 3

| level | group | agreement | category_distance | expected_lower | expected_mean | expected_upper | interval_method | interval_probability | mcse_status | mean_mcse | metric_status | n_opportunities | n_persons | observed_count | observed_rate | observed_se | observed_se_status | se_unit |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
|  | overall | exact | 0 | 0.36126570692505006 | 0.3755093317173964 | 0.38998434832659384 | equal_tailed | 0.95 | available | 0.00012459058567368733 | descriptive | 2500 | 50 | 911 | 0.3644 | 0.015175598028091148 | approximate | person |
|  | overall | adjacent | 1 | 0.783462555876694 | 0.8026737411070096 | 0.8206354895767293 | equal_tailed | 0.95 | available | 0.00016391721115863398 | descriptive | 2500 | 50 | 2003 | 0.8012 | 0.012846471762110165 | approximate | person |
| R1 | rater | exact | 0 | 0.32194018529180657 | 0.3435618361611108 | 0.3643880643772332 | equal_tailed | 0.95 | available | 0.00017395702507991192 | descriptive | 1000 | 50 | 324 | 0.324 | 0.016796501093370365 | approximate | person |

*29 additional row(s) omitted.*

### q_matrix

Fixed Q specifies the loading pattern. Active loadings are positive and estimated; latent correlation is identity. Representability does not establish identification or recovery for every Q geometry.


### q_matrix / rows

- Rows: 10
- Preview rows: 3

| item | dimension | dimension_label | active | loading |
| --- | --- | --- | --- | --- |
| I1 | 1 | dim=1 | true | estimated_positive |
| I1 | 2 | dim=2 | false | fixed_zero |
| I2 | 1 | dim=1 | true | estimated_positive |

*7 additional row(s) omitted.*

### mcmc_budget_guidance

MCMC-budget guidance is not connected for this MGMFRM result.


### prior_policy

MGMFRM normalized exchangeable prior; zero-sum block scales are kernel SDs. For a centered block of length n, marginal SD is kernel SD times sqrt((n-1)/n), and pairwise contrast SD is sqrt(2) times kernel SD when a contrast exists. Source log-consistency means depend on the distinguished rater and are reported explicitly. Density is declared on last-reconstructed free coordinates; no additional lognormal Jacobian is added. All scales are fixed inputs; statistical acceptance is not established.


### prior_policy / rows

- Rows: 6
- Preview rows: 3

| parameter | block | mean | active | contrast_sd | distribution | estimated | marginal_sd | meaning | value |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| person_sd | person | 0 | true |  | independent_normal | false | 1 | SD of independent normal coordinates | 1 |
| item_sd | item | 0 | true |  | independent_normal | false | 1 | SD of independent normal coordinates | 1 |
| log_discrimination_sd | item_dimension_discrimination | 0 | true |  | independent_normal | false | 0.5 | SD of independent normal coordinates | 0.5 |

*3 additional row(s) omitted.*

### pooling_policy

Ability dimensions have independent priors with fixed scales. Centered prior blocks induce the saved dependence across raters and steps. No variance components or latent correlations are estimated.


### posterior

Raw computational coordinates under the saved normalized prior. All retained draws; central 95.0% credible intervals. Positive loadings and consistencies are reported in model coordinates.


### posterior / rows

- Rows: 128
- Preview rows: 3

| parameter | parameter_space | mean | sd | median | lower | upper | lower_probability | upper_probability | direction | n_draws | practical_equivalence | probability_above_rope | probability_below_rope | probability_equal | probability_in_rope | probability_negative | probability_of_direction | probability_positive | reference | rope_lower | rope_probability_threshold | rope_upper |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| person[P1,dim=1] | raw_unconstrained | -0.7984750484888838 | 0.4299662130483597 | -0.7903700807915786 | -1.693829675857368 | 0.015587523247313176 | 0.025 | 0.975 | negative | 4000 | not_requested |  |  | 0 |  | 0.97125 | 0.97125 | 0.02875 | 0 |  |  |  |
| person[P1,dim=2] | raw_unconstrained | -0.6072459330980141 | 0.30822016276519426 | -0.5941896674757743 | -1.2558989876803501 | -0.0168438325070138 | 0.025 | 0.975 | negative | 4000 | not_requested |  |  | 0 |  | 0.97925 | 0.97925 | 0.02075 | 0 |  |  |  |
| person[P10,dim=1] | raw_unconstrained | 0.09261725059449008 | 0.43497916348402504 | 0.09404923343154395 | -0.7615706615782994 | 0.9462237057932825 | 0.025 | 0.975 | positive | 4000 | not_requested |  |  | 5.551115123125783e-17 |  | 0.414 | 0.586 | 0.586 | 0 |  |  |  |

*125 additional row(s) omitted.*

### direct_posterior

Named model coordinates with reconstructed zero-sum severities/steps and product-one consistencies. All retained draws; central 95.0% credible intervals. MCSE measures simulation precision, not posterior uncertainty. Fixed intervals represent constraints; inactive Q loadings are structural zeros.


### direct_posterior / rows

- Rows: 140
- Preview rows: 3

| parameter | parameter_space | block | dimension | dimension_label | mean | median | lower | upper | derived | fixed | interval_probability |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| person[P1,dim=1] | model_coordinate | person | 1 | dim=1 | -0.7984750484888838 | -0.7903700807915786 | -1.6938296758573679 | 0.015587523247313176 | false | false | 0.95 |
| person[P1,dim=2] | model_coordinate | person | 2 | dim=2 | -0.6072459330980141 | -0.5941896674757743 | -1.25589898768035 | -0.0168438325070138 | false | false | 0.95 |
| person[P10,dim=1] | model_coordinate | person | 1 | dim=1 | 0.09261725059449008 | 0.09404923343154395 | -0.7615706615782994 | 0.9462237057932825 | false | false | 0.95 |

*137 additional row(s) omitted.*

### direct_posterior / mcse_rows

- Rows: 140
- Preview rows: 3

| parameter | parameter_space | block | dimension | dimension_label | convergence_review_required | derived | draws_per_chain | fixed | mcse_method | mcse_status | mean_mcse | minimum_draws_per_chain | n_chains | precision_decision | precision_threshold_applied | sd_mcse | split_chains | total_draws |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| person[P1,dim=1] | model_coordinate | person | 1 | dim=1 | true | false | 1000 | false | mcmcdiagnostictools_ess_asymptotic_variance | available | 0.006785230348673702 | 10 | 4 | not_applied | false | 0.006826878962274609 | 2 | 4000 |
| person[P1,dim=2] | model_coordinate | person | 2 | dim=2 | true | false | 1000 | false | mcmcdiagnostictools_ess_asymptotic_variance | available | 0.005110690740894399 | 10 | 4 | not_applied | false | 0.00504082901926104 | 2 | 4000 |
| person[P10,dim=1] | model_coordinate | person | 1 | dim=1 | true | false | 1000 | false | mcmcdiagnostictools_ess_asymptotic_variance | available | 0.006409730367612483 | 10 | 4 | not_applied | false | 0.007931575111197171 | 2 | 4000 |

*137 additional row(s) omitted.*

### calibration

Calibration analysis is not connected for this MGMFRM result.


### dff

DFF analysis is not connected for this MGMFRM result.

